from django.apps import AppConfig


class CacteaConfig(AppConfig):
    name = 'CACTEA'
